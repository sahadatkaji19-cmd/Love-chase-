LOVE CHASE - FREE GITHUB PAGES UPLOAD

1. Extract this ZIP in the iPhone Files app.
2. Open github.com in Safari and sign in.
3. Tap +, then New repository.
4. Name it love-chase and set it to Public. Create repository.
5. Choose Add file > Upload files.
6. Upload ALL files inside this extracted folder (index.html, manifest.webmanifest, sw.js, both icon PNGs). Do not upload the ZIP itself.
7. Commit changes.
8. In repository Settings > Pages, under Build and deployment choose Deploy from a branch, branch main, folder /(root), then Save.
9. Wait a minute or two. GitHub will show a website address ending in github.io/love-chase.
10. Open that address in Safari on iPhone, tap Share > Add to Home Screen.

This is a simple free 2D prototype, not a full 3D native app. Do not share private photos or passwords/OTP codes.
